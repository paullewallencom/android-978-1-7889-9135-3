package com.example.jonnd.fuelfinder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FillUpEditActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fill_up_edit);
    }
}
