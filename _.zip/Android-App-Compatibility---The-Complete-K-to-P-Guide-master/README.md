# Android-App-Compatibility---The-Complete-K-to-P-Guide
Android App Compatibility - The Complete K-to-P Guide [Video], published by Packt
